<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="shop.css">
</head>
<body>
<nav>
      <a href="_index.php"><img src="photo/logo.png" class="logo" height="100" width="200"></a>
        <ul>
            <li><a href="_index.php">Home</a></li>
            <li><a href="shop.php" style="background-color:goldenrod; opacity:0.9">Shop Now</a></li>
            <li><a href="blog.php">Blog</a></li>
            <li><a href="help.php">help</a></li>
            </ul>
    </nav><center>
<div id="section" style="margin-left: auto; margin-right:auto;">
	
		<center>
<div id="pic1"><a href="racket.php"> <img id="pic" src="photo/racket.gif" width=480 height=375> </a>
<a href="racket.php"><div id="centered">Buy A Racket</div></a>
</div>

<div id="pic2"><a href="shoe.php"> <img id="pic" src="photo/shoe.gif" width=480 height=375  ></a>
<a href="shoe.php"><div id="centered">Buy A Shoe</div></a>
</div>

<div id="pic3"><a href="shuttle.php"> <img id="pic" src="photo/shuttle.gif" width=480 height=375 ></a>
<a href="shuttle.php"><div id="specialcentered">Buy A Shuttlecock</div></a>
</div>
</center>

	</div></center>

<?php
include 'footer.php';
?>
</body>
</html>