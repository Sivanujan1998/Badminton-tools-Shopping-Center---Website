<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="footer.css">
</head>
<body>
    <footer class="f1">
    <div class="wrapper">
 <table class="ft">
 	<tr>
 		<td>
 <table class="ft">
 	
	<tr>
		<th><strong>Info</strong></th>
		<th><strong>Help</strong></th>
		<th><strong>Quick Links</strong></th>
	</tr>
	<tr>
		<td><a href="#">social responsibility</a></td>
        <td><a style="text-decoration: none; color:white">contact us</a>
    <p align=left style="font-size: 15px; color:goldenrod; padding-left:20%">Darmashena road,No-56/3<br>
    Colombo 15,<br>
    tel No- +947791268740<br>
    E-mail- ShamShopping@gmail.com
</p>
    </td>
		<td><a href="#">terms and conditions</a></td>
	</tr>
    <tr>
    	<td><a href="#">business with us</a></td>
    	<td><a href="#">FAQs</a></td>
    	<td><a href="#">business with us</a></td>
    </tr>
    
 </table>
 </td>
 <td><img src="photo/logo.png"></td>
    </tr>

</table>
<div class="social">
<table class="ft">
    <tr>
        <td><a href="facebook.com"><img src="photo/facebook.png" width="70px" height="70px"></a></td>
        <td><a href="instagram.com"><img src="photo/insta.png" width="70px" height="70px"></a></td>
        <td><a href="linkedin.com"><img src="photo/linkedin.png" width="70px" height="70px"></a></td>
        <td><a href="twitter.com"><img src="photo/twitter.png" width="70px" height="70px"></a></td>
    </tr>
</table>
</div>
 <div class="column span_16_of_16 copyright space_top"> 
      <p style="text-align:center; color:gold; font-size:25px;">© <script>document.write((new Date()).getFullYear());</script>ShamSIVA All rights reserved.</p>
    </div>
 </div>
   
</body>
</html>