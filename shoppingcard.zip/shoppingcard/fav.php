<?php
$var_value = $_SESSION['varname']; 
echo $var_value;
?>