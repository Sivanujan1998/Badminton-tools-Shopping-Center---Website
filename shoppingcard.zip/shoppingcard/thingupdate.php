<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body><div id="hidethis2" style="display:none;" >
<form method="POST" action="thingupdate1.php" ><label>Model Number</label>
       <input type="text" placeholder="Enter the model number" required name="mn">
       <input type="submit" value="Search now">
       
      
     
</form>
</div> 
</body>
</html>