<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Now</title>
    <link rel="stylesheet" type="text/css" href="order.css">
    <link rel="stylesheet" type="text/css" href="signinresult.css">
    <link rel="stylesheet" type="text/css" href="buy.css">
    

   
</head>

<body style="margin:0;">
<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">order Now</button>
        
        <?php
         include 'order.php';
         ?>

    
  <?php include 'footer.php'?>
<script type="text/javascript" src="order.js"></script>
<script src="signinresult.js"></script>
</body>
</html>