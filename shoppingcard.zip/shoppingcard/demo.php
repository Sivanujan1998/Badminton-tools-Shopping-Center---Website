
<button class="sub" onclick="myFunction()">Modify Account</button>
    <div id="modi"></div>

    <script>
function myFunction() {
  document.getElementById("modi").innerHTML ="siva";
}
</script>