function toggle3(){
    if( document.getElementById("hidethis3").style.display=='none'){
        document.getElementById("hidethis3").style.display = '';
       
      }else{
        document.getElementById("hidethis3").style.display = 'none';
      
      }
}
function toggle2(){
    if( document.getElementById("hidethis2").style.display=='none'){
        document.getElementById("hidethis2").style.display = '';
       
      }else{
        document.getElementById("hidethis2").style.display = 'none';
      
      }
}
function toggle1(){
    if( document.getElementById("hidethis1").style.display=='none'){
        document.getElementById("hidethis1").style.display = '';
       
      }else{
        document.getElementById("hidethis1").style.display = 'none';
      
      }
}